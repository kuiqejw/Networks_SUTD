#!/bin/bash 
echo "Use http://localhost:8888/queue.png to see the figure on your browser"
python -m SimpleHTTPServer 8888
